# HW 7 Submission

## Mary Gooneratne and Luke Truitt

### nn.py

Contains all relevant methods for both questions

### submission.ipynb

Has an example of running this and printing the output of our custom model.
