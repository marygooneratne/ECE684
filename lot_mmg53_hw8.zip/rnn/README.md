# HW 8 Submission

## Mary Gooneratne and Luke Truitt

### rnn.py

Contains all relevant methods for question one

### custom_rnn.py

Contains all relevant metods for question two

### submission.ipynb

Has an example of running this and printing the output of our custom model.
