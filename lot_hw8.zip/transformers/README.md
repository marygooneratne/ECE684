## Luke Truitt Transformers

# Overall, I believe I understand how both of these structures work, I have had some problems with actually implementing the data.

# I've seen good results on the LSTM, pretty average results for the Transformer.

# My script for preprocessing is in the preprocessing.py file

# All LSTM code is in the hw.py file

# All Transformer code is in the transformer.py file

# All testing is in submission.ipynb
